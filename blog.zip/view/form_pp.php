<a class="retour" href="index.php?action=profil">retour</a>
    <form method="POST" action="index.php?action=photoProfil" enctype="multipart/form-data">
        <label for="image">Photo de profil</label>
        <input type="file" name="image" id="image" required>

        <br>
        <br>
        <input type="submit">
    </form>
